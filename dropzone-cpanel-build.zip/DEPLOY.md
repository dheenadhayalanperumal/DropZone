# DropZone — cPanel deployment package

Upload everything inside `public_html/` (this folder) into your cPanel account's
`public_html/` (or a subdomain's document root). Layout:

```
public_html/
├── index.html, _next/, login/, play/, ...   ← static frontend (Next.js export)
├── api/            ← web-facing PHP front controller (index.php + .htaccess)
├── src/            ← PHP classes — blocked from direct HTTP access (.htaccess)
├── config/         ← DB config — blocked from direct HTTP access (.htaccess)
├── migrations/      ← SQL migrations — blocked (.htaccess)
└── cron/           ← cron scripts — blocked (.htaccess)
```

## 1. Database
Create the DB via cPanel → MySQL Databases (cPanel prefixes the name with your
account username, e.g. `brandycrush_dropzone` — use that real name everywhere
below, not plain `dropzone`).

Quickest way to get schema + full demo data (including working admin logins)
in one shot: import `public_html/../dummy_data.sql` (i.e. `backend/dummy_data.sql`
from the source repo) via phpMyAdmin → Import, **after deleting its first two
lines** (`CREATE DATABASE...` / `USE dropzone;`) since your DB is already
selected and prefixed differently. It creates:
```
admin@dropzone.test   / password   (owner)
manager@dropzone.test / password   (admin)
viewer@dropzone.test  / password   (viewer)
```

Otherwise, run migrations the normal way:
```bash
php public_html/cron/migrate.php     # applies migrations/*.sql, safe to re-run
php public_html/cron/seed.php        # optional demo data — NOT safe to re-run twice
```

## 2. Backend config
In `public_html/config/`:
```bash
cp config.example.php config.php
```
Edit `config.php` with your real DB host/name/user/pass (from cPanel MySQL
Databases), and set `cors_origins` to your domain if the API is ever called
cross-origin.

## 3. Schedule the drop-closing cron
In cPanel → Cron Jobs, every 5 minutes:
```
*/5 * * * * php /home/YOURUSER/public_html/cron/close_drops.php
```

## 4. Verify
- API health check: `https://yourdomain.com/api/health` → `{"status":"ok",...}`
- Admin panel: `https://yourdomain.com/login`
- Customer experience: `https://yourdomain.com/play`

The frontend was built with a relative API base (`/api`), so it works on
whatever domain serves it. If the API instead lives on a separate subdomain,
rebuild with `NEXT_PUBLIC_API_BASE=https://api.yourdomain.com npm run build`
and update `cors_origins` in `config.php` accordingly.

## Known cPanel gotcha: admin login works, every call after it 401s

Apache commonly strips the `Authorization` header before PHP ever sees it,
so `POST /api/admin/login` succeeds (no auth required) but `stats`,
`analytics`, `campaigns`, etc. all return 401 even with a valid token.
Both pieces of the fix are already in this build:

- `api/.htaccess` forwards the header via `RewriteRule ... [E=HTTP_AUTHORIZATION:%1]`
- `src/Auth.php`'s `bearerToken()` checks `HTTP_AUTHORIZATION`,
  `REDIRECT_HTTP_AUTHORIZATION` (Apache renames it on the internal redirect
  triggered by the rewrite-to-index.php rule), and `getallheaders()`.

If you still see this after deploying, your host is stripping the header at
the FastCGI layer entirely — ask them to enable `CGIPassAuth On` for the
account (Apache 2.4.13+), or switch the admin frontend to send the token via
a custom header (e.g. `X-Admin-Token`) instead of `Authorization`, which
isn't affected by this stripping behavior.
